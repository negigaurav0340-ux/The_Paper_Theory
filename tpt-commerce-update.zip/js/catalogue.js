(async()=>{
'use strict';
await Promise.all([window.TPT_CATALOGUE_READY,window.TPT_PRODUCTS_READY,window.TPT_PACKS_READY]);
const catalogue=window.STICKER_CATALOGUE||[],packs=window.STICKER_PACKS||[],byCode=new Map(catalogue.map(s=>[s.code,s]));
const $=id=>document.getElementById(id),safe=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const layout=$('sheetLayout'),finish=$('sheetFinish'),key='tpt-sheet-editor-v2';let selected=[],filter='All';
try{const draft=JSON.parse(localStorage.getItem(key));if(draft){layout.value=['16','12','6','long4','long2','individual'].includes(draft.layout)?draft.layout:'16';finish.value=draft.finish==='holo'?'holo':'regular';selected=(draft.codes||[]).filter(c=>byCode.has(c));}else{selected=(JSON.parse(localStorage.getItem('tpt-selected-sticker-codes'))||[]).filter(c=>byCode.has(c)).slice(0,16);}}catch{}
const individual=()=>layout.value==='individual';
const capacity=()=>individual()?99:layout.value==='long4'?4:layout.value==='long2'?2:Number(layout.value);
const longMode=()=>layout.value.startsWith('long');
const eligible=s=>longMode()?s.kind==='long'&&s.sheet_count===capacity():s.kind!=='long';
selected=selected.filter(c=>eligible(byCode.get(c))).slice(0,capacity());if(longMode()&&selected.length)selected=selected.filter(c=>byCode.get(c).pack_id===byCode.get(selected[0]).pack_id);
const price=()=>individual()?selected.length*10:longMode()?(finish.value==='holo'?199:99):window.CATALOGUE.products.find(p=>p.id==='PACK-CUSTOM')?.variants.find(v=>v.id===`${finish.value==='holo'?'HOLO':'REG'}-${capacity()}`)?.price??99;
const complete=()=>individual()?selected.length>0:selected.length===capacity();
function persist(){try{localStorage.setItem(key,JSON.stringify({layout:layout.value,finish:finish.value,codes:selected}));}catch{$('editorStatus').textContent='Browser storage unavailable; keep this page open.';}}
function update(){
 if(individual())finish.value='regular';finish.disabled=individual();
 $('shopSelection').textContent=individual()?'Add stickers to bag ↗':'Add sheet to bag ↗';
 $('selectedCount').textContent=selected.length;$('selectionHint').textContent=individual()?`${selected.length} × ₹10 · ₹${price()} total`:complete()?'Sheet complete · ready to add to bag':`Choose ${capacity()-selected.length} more sticker(s) · repeats welcome`;
 $('sheetSummary').textContent=individual()?`Individual 2-inch stickers · ₹10 each · ${selected.length} chosen · ₹${price()} total`:`${capacity()} ${longMode()?'long ':''}stickers per sheet · ₹${price()} · ${selected.length} selected.`;
 $('shopSelection').disabled=!complete();$('downloadSheet').disabled=!complete()||individual();$('printSheet').disabled=!complete()||individual();$('sheetEditor').hidden=individual();
 $('editorPreview').className='editor-preview '+(longMode()?layout.value:'regular'+capacity());
 $('editorPreview').innerHTML=Array.from({length:individual()?0:capacity()},(_,i)=>{const s=byCode.get(selected[i]);return `<div class="editor-slot">${s?`<img src="${safe(s.image)}" alt="${safe(s.name||s.code)}"><small>${safe(s.code)}</small><div class="slot-controls"><button data-move="${i}" data-dir="-1" ${i===0?'disabled':''} aria-label="Move ${safe(s.code)} earlier">←</button><button data-move="${i}" data-dir="1" ${i===selected.length-1?'disabled':''} aria-label="Move ${safe(s.code)} later">→</button><button data-remove="${i}" aria-label="Remove ${safe(s.code)}">×</button></div>`:`<small>Choose design ${i+1}</small>`}</div>`;}).join('');
 $('catalogueRoot').querySelectorAll('.sticker[data-code]').forEach(tile=>{const code=tile.dataset.code,n=selected.filter(c=>c===code).length;tile.querySelector('output').textContent=n;tile.classList.toggle('is-selected',n>0);const item=byCode.get(code),blocked=selected.length>=capacity()||(longMode()&&selected.length&&item.pack_id!==byCode.get(selected[0]).pack_id);tile.querySelectorAll('[data-sticker-step="1"]').forEach(b=>b.disabled=Boolean(blocked));tile.querySelector('[data-sticker-step="-1"]').disabled=n===0;});
 document.body.classList.toggle('holo-selected',finish.value==='holo');persist();
}
function render(){
 const query=$('catalogueSearch').value.trim().toLowerCase(),items=catalogue.filter(s=>eligible(s)&&(filter==='All'||s.category===filter)&&(!query||`${s.code} ${s.name||''} ${s.pack} ${s.category}`.toLowerCase().includes(query)));
 $('catalogueResultCount').textContent=`${items.length} compatible designs`;
 const groups=[...new Set(items.map(s=>s.pack_id))];
 $('catalogueRoot').innerHTML=groups.map(id=>{const p=packs.find(p=>p.id===id),list=items.filter(s=>s.pack_id===id),slug=p?.slug||id;return `<section class="pack-section" id="${safe(slug)}"><div class="pack-head"><div><p>${safe(list[0].category)}</p><h2>${safe(p?.name||list[0].pack)}</h2></div><b>${list.length} designs</b></div>${longMode()?`<p>${capacity()===4?'Large':'Extra Large'} · matching ${capacity()}-sticker sheet · ₹99 <button class="pack-select" data-exact-pack="${safe(id)}">Use this complete long sheet</button></p>`:''}<div class="grid">${list.map(s=>`<div class="sticker" data-code="${safe(s.code)}"><button class="sticker-art" type="button" data-sticker-step="1" data-code="${safe(s.code)}" aria-label="Add ${safe(s.code)}"><img src="${safe(s.image)}" alt="${safe(s.name||s.code)}" loading="lazy"></button><span class="sticker-name">${safe(s.name||s.category)}<small class="code">${safe(s.code)}</small></span><div class="sticker-qty"><button type="button" data-sticker-step="-1" data-code="${safe(s.code)}" aria-label="Remove one ${safe(s.code)}">−</button><output aria-live="polite" aria-label="Quantity of ${safe(s.code)}">0</output><button type="button" data-sticker-step="1" data-code="${safe(s.code)}" aria-label="Add one ${safe(s.code)}">+</button></div></div>`).join('')}</div></section>`;}).join('')||'<p>No matching designs. Try another search or sheet type.</p>';
 update();
}
function renderFilters(){const groups=[...new Set(catalogue.filter(eligible).map(s=>s.category))];$('catalogueFilters').innerHTML=['All',...groups].map(s=>`<button data-filter="${safe(s)}" class="${s===filter?'active':''}" aria-pressed="${s===filter}">${safe(s)}</button>`).join('');}
$('catalogueFilters').onclick=e=>{const b=e.target.closest('[data-filter]');if(!b)return;filter=b.dataset.filter;renderFilters();render();};
$('catalogueSearch').oninput=render;
$('catalogueRoot').onclick=e=>{const step=e.target.closest('[data-sticker-step]');if(step){const code=step.dataset.code,item=byCode.get(code);if(Number(step.dataset.stickerStep)>0){if(!eligible(item)||selected.length>=capacity()||(longMode()&&selected.length&&item.pack_id!==byCode.get(selected[0]).pack_id))return;selected.push(code);}else{const i=selected.lastIndexOf(code);if(i>=0)selected.splice(i,1);}try{navigator.vibrate?.(12);}catch{}window.TPTAnalytics?.track('catalogue_selection',{itemCount:selected.length,surface:layout.value});update();return;}const b=e.target.closest('[data-exact-pack]');if(!b)return;const p=packs.find(p=>p.id===b.dataset.exactPack);if(p?.kind==='long'&&p.count===capacity()){selected=p.code_list.slice();update();$('sheetEditor').open=true;$('sheetEditor').scrollIntoView({behavior:'smooth'});}};
$('editorPreview').onclick=e=>{const remove=e.target.closest('[data-remove]'),move=e.target.closest('[data-move]');if(remove)selected.splice(Number(remove.dataset.remove),1);else if(move){const i=Number(move.dataset.move),j=i+Number(move.dataset.dir);if(j>=0&&j<selected.length)[selected[i],selected[j]]=[selected[j],selected[i]];}update();};
layout.onchange=()=>{selected=[];filter='All';$('editorStatus').textContent='Choose designs for this sheet type.';renderFilters();render();};finish.onchange=update;
$('clearCodes').onclick=()=>{selected=[];update();};

$('copyCodes').onclick=async()=>{if(!selected.length)return;try{await navigator.clipboard.writeText(selected.join(', '));$('editorStatus').textContent='Codes copied.';}catch{window.prompt('Copy your codes',selected.join(', '));}};
$('shopSelection').onclick=()=>{if(!complete())return;const sheet={codes:selected,finish:finish.value,...(individual()?{kind:'individual'}:longMode()?{kind:'long',packId:byCode.get(selected[0]).pack_id}:{kind:'regular',layout:Number(layout.value)})};location.href='index.html?stickerSheets='+encodeURIComponent(JSON.stringify([sheet]))+'#shop';};
$('printCatalogue').onclick=()=>window.print();$('printSheet').onclick=()=>{if(!complete())return;document.body.classList.add('print-sheet-only');window.print();};window.addEventListener('afterprint',()=>document.body.classList.remove('print-sheet-only'));
const load=src=>new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>reject(Error('A sticker image could not be loaded. Please retry.'));im.src=src;});
$('downloadSheet').onclick=async()=>{if(!complete())return;window.TPTAnalytics?.track('sheet_export',{itemCount:selected.length,surface:layout.value});const button=$('downloadSheet');button.disabled=true;const codes=selected.slice(),mode=layout.value;try{
 $('editorStatus').textContent='Preparing original artwork…';const images=await Promise.all(codes.map(c=>load(byCode.get(c).image)));
 const canvas=document.createElement('canvas');canvas.width=2480;canvas.height=3508;const ctx=canvas.getContext('2d');ctx.fillStyle='white';ctx.fillRect(0,0,canvas.width,canvas.height);
 const regular=!mode.startsWith('long'),n=Number(mode),cols=regular?(n===6?2:n===12?3:4):(mode==='long2'?2:4),rows=regular?(n===6?3:4):1,cw=regular?(n===6?900:n===12?600:300):600,ch=regular?cw:mode==='long2'?3000:1800,gap=regular?20:10,totalW=cols*cw+(cols-1)*gap,totalH=rows*ch+(rows-1)*gap,x0=(canvas.width-totalW)/2,y0=(canvas.height-totalH)/2;
 images.forEach((im,i)=>{const ratio=Math.min(cw/im.naturalWidth,ch/im.naturalHeight),w=im.naturalWidth*ratio,h=im.naturalHeight*ratio;ctx.drawImage(im,x0+(i%cols)*(cw+gap)+(cw-w)/2,y0+Math.floor(i/cols)*(ch+gap)+(ch-h)/2,w,h);});
 const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw Error('Could not export this sheet.');const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='The-Paper-Theory-'+mode+'-sheet.png';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);$('editorStatus').textContent='Downloaded A4 artwork (2480 × 3508). Print on A4 without cropping. Cricut registration marks must be added in Design Space.';
 }catch(e){$('editorStatus').textContent=e.message;}finally{button.disabled=!complete();}};
const intro=document.querySelector('.intro > div > p:last-child');intro.textContent='Build a regular sheet of 16 (4 × 4), 12 (3 × 4) or 6 (2 × 3) designs for ₹99. Large long stickers use four 6 × 2-inch designs; Extra Large use two 10 × 2-inch designs for ₹99. Each long sheet uses one matching pack.';
const requestedFormat=new URLSearchParams(location.search).get('format');if(['16','12','6','long4','long2','individual'].includes(requestedFormat)){layout.value=requestedFormat;selected=[];}
renderFilters();render();
if(location.hash){const p=packs.find(p=>p.slug===decodeURIComponent(location.hash.slice(1)));if(p?.kind==='long'){layout.value=p.count===2?'long2':'long4';selected=[];renderFilters();render();}document.getElementById(location.hash.slice(1))?.scrollIntoView();}
})();
